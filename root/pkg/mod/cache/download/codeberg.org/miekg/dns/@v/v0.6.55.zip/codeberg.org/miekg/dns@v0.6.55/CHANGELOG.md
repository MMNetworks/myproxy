# Changelog

This is the generated changelog for codeberg.org/miekg/dns.


## v0.6.21 - 2026-01-06

8 commits.


## v0.6.20 - 2026-01-02

1 commits.


## v0.6.19 - 2026-01-02

19 commits. With the following change log.

* 395a31c Allow external EDNS0 options via the Packer interface. (Miek Gieben)
* df6df38 Rename CertXXXX to CERTXxxx as this is a CERT RR constant - inline with LOC and ZONEMD. (Miek Gieben)

## v0.6.18 - 2025-12-22

4 commits. With the following change log.

* 23a2cb2 Dnshttp: NewRequest: use url.JoinPath and set m.ID = 0. (Miek Gieben)

## v0.6.17 - 2025-12-22

6 commits. With the following change log.

* 1120fee ZoneParser: IncludeFS public instead of SetIncludeFS. (Miek Gieben)

## v0.6.16 - 2025-12-22

6 commits.


## v0.6.15 - 2025-12-21

1 commits.


## v0.6.14 - 2025-12-21

2 commits.


## v0.6.13 - 2025-12-21

2 commits.


## v0.6.12 - 2025-12-21

1 commits.


## v0.6.11 - 2025-12-21

2 commits.


## v0.6.10 - 2025-12-21

3 commits.


## v0.6.9 - 2025-12-21

13 commits.


## v0.6.8 - 2025-12-20

14 commits.


## v0.6.7 - 2025-12-20

23 commits. With the following change log.

* f843177 Atomdns: add co.Handlers to get a list of previous handelers. Fixes: #508. (Miek Gieben)

## v0.6.6 - 2025-12-19

57 commits. With the following change log.

* 326fb72 Dnshttp: do MsgAcceptFunc similar to main package. (Miek Gieben)
* eece5cd Atomdns: add kill handler. (Miek Gieben)
* 760ee12 Atomdns: log ecs/address and id/id if set in the context. (Miek Gieben)
* fe27af3 Atomdns,id: add id handler that adds a request ID. (Miek Gieben)

## v0.6.5 - 2025-12-17

7 commits. With the following change log.

* a8f63ce Fix SUBNET unpacking bug. (Miek Gieben)

## v0.6.4 - 2025-12-16

10 commits.


## v0.6.3 - 2025-12-16

25 commits.


## v0.6.2 - 2025-12-15

18 commits.


## v0.6.1 - 2025-12-14

10 commits.


## v0.6.0 - 2025-12-13

10 commits.


## v0.5.38 - 2025-12-13

6 commits.


## v0.5.37 - 2025-12-13

31 commits.


## v0.5.36 - 2025-12-10

8 commits.


## v0.5.35 - 2025-12-10

13 commits.


## v0.5.34 - 2025-12-06

6 commits. With the following change log.

* d2701d1 Rename NewDefaultTransport to NewTransport. (Miek Gieben)
* d2701d1 Prepare to get rid of ExchangeWithConn by overriding Transport's Dial. (Miek Gieben)

## v0.5.33 - 2025-12-05

39 commits. With the following change log.

* 43ba136 Atomdns: add tsig handler. (Miek Gieben)
* c2427ee Atomdns: rename subnet to ecs. (Miek Gieben)
* 7519646 Add subnet handler, a edns0 subnet client context setter. (Miek Gieben)
* 990fd1c Atomdns,geoip: set region codes. Also allow []string in the context. (Miek Gieben)

## v0.5.32 - 2025-12-03

3 commits. With the following change log.

* 773ecbe Rename some RFC3597 rdata fields. Fix sort by adding Type() method. (Miek Gieben)

## v0.5.31 - 2025-12-03

9 commits.


## v0.5.30 - 2025-11-27

19 commits.


## v0.5.29 - 2025-11-25

7 commits.


## v0.5.28 - 2025-11-25

4 commits.


## v0.5.27 - 2025-11-25

48 commits. With the following change log.

* 80d013d Atomdns,acl: use context.Context for matching as well. (Miek Gieben)

## v0.5.26 - 2025-11-17

63 commits. With the following change log.

* 2d48353 Add all DSO types. (Miek Gieben)

## v0.5.25 - 2025-11-09

19 commits.


## v0.5.24 - 2025-11-07

10 commits.


## v0.5.23 - 2025-11-06

23 commits.


## v0.5.22 - 2025-11-05

17 commits.


## v0.5.21 - 2025-11-04

8 commits.


## v0.5.20 - 2025-11-04

7 commits.


## v0.5.19 - 2025-11-03

8 commits.


## v0.5.18 - 2025-11-03

6 commits.


## v0.5.17 - 2025-11-02

20 commits. With the following change log.

* 6720620 Atomdns, add _url_ handler. (Miek Gieben)
* 7d0ccec Add complete ZONEMD support, implement ZONEMD.Sign. (Miek Gieben)

## v0.5.16 - 2025-10-29

53 commits. With the following change log.

* bdd8cba Massively drop mem usage for creating/verifying DNSSEC signatures. (Miek Gieben)
* 86f8e37 Atomdns when authoritative, set the AA bit, for non delegation answers. (Miek Gieben)

## v0.5.15 - 2025-10-24

49 commits. With the following change log.

* f47aa35 Atomdns: the HUP signal reloads the process. (Miek Gieben)

## v0.5.14 - 2025-10-16

25 commits. With the following change log.

* 6704b6e IncludeAllowFunc now tells the zone parser if includes are allowed. (Miek Gieben)

## v0.5.13 - 2025-10-13

3 commits.


## v0.5.12 - 2025-10-13

16 commits. With the following change log.

* b9fcf50 Use *dnszone.Node in zones, makes inplace updates possible. (Miek Gieben)

## v0.5.11 - 2025-10-10

11 commits. With the following change log.

* 06ff288 Atomdns: fix resign wakeup. (Miek Gieben)

## v0.5.10 - 2025-10-09

14 commits.


## v0.5.9 - 2025-10-08

31 commits. With the following change log.

* 30e21bd Dns: remove *pack.StringOctet; can also be done via StringAny. (Miek Gieben)
* 2b36083 Use slog with fields to log the query: example.org. remote=::1 port=53806 id=61098 type=MX class=IN name=example.org. network=udp size=52 bufsize=1232 opcode=QUERY. (Miek Gieben)

## v0.5.8 - 2025-10-05

9 commits.


## v0.5.7 - 2025-10-05

21 commits. With the following change log.

* 9f5b6f4 Bump atomdns to 013. (Miek Gieben)
* 33ba89c Atomdns log: guard the USR1 signal handler with a sync.Once. (Miek Gieben)

## v0.5.6 - 2025-10-04

20 commits. With the following change log.

* c07ab99 Fix panic when the connection was a *tls.Conn. (Miek Gieben)
* 216eadf Atomdns: add DOT server support. (Miek Gieben)
* 49f0d08 Atomdns: add DOT serving. (Miek Gieben)

## v0.5.5 - 2025-10-03

22 commits. With the following change log.

* 4f2cb96 Use Let's Encrypt for certificates for DOH. (Miek Gieben)
* b3e6ee4 Atomdns: add ACME TLS. (Miek Gieben)

## v0.5.4 - 2025-10-02

48 commits. With the following change log.

* ea4f116 Atom: for IP lists, allow interface names. (Miek Gieben)
* a4e84a4 DeepCopy is now Clone. (Miek Gieben)
* 2f24c1f Add DOH helper utils in new package dnshttp. (Miek Gieben)
* 4ddec12 Just like CoreDNS use builtin config when nothing is found. (Miek Gieben)

## v0.5.3 - 2025-09-30

62 commits.


## v0.5.2 - 2025-09-25

35 commits.


## v0.5.1 - 2025-09-24

79 commits.


## v0.5.0 - 2025-09-20

101 commits.


## v0.1.12 - 2025-09-15

107 commits.


## v0.1.11 - 2025-09-10

36 commits.


## v0.1.10 - 2025-09-08

102 commits.


## v0.1.9 - 2025-09-03

43 commits.


## v0.1.8 - 2025-09-01

26 commits.


## v0.1.7 - 2025-08-29

18 commits.


## v0.1.6 - 2025-08-29

20 commits.


## v0.1.5 - 2025-08-27

50 commits.


## v0.1.4 - 2025-08-25

45 commits.


## v0.0.4 - 2025-08-23

22 commits.


## v0.0.3 - 2025-08-22

67 commits.


*Generated by <https://codeberg.org/miekg/gitcl>.*
